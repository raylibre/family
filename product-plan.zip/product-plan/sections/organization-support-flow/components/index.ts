export { PartnershipWidget } from './PartnershipWidget'
