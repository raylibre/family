import { useState, useEffect } from 'react'
import type { LandingPageProps, Locale, Partner } from '../types'

// ─── Brand tokens ──────────────────────────────────────────────────────────────
const BLUE        = 'oklch(0.42 0.175 260)'
const BLUE_DEEP   = 'oklch(0.30 0.14 260)'
const BLUE_FAINT  = 'oklch(0.95 0.025 258)'
const GOLD        = 'oklch(0.83 0.18 88)'
const GOLD_DEEP   = 'oklch(0.62 0.15 88)'
const CORAL       = 'oklch(0.68 0.20 24)'
const CORAL_DEEP  = 'oklch(0.55 0.20 24)'
const CREAM       = 'oklch(0.985 0.012 75)'
const NAVY        = 'oklch(0.18 0.055 261)'

// ─── Decorative SVGs ───────────────────────────────────────────────────────────
function SunflowerDecor({
  size = 120,
  color = 'currentColor',
  opacity = 0.12,
  className = '',
}: {
  size?: number
  color?: string
  opacity?: number
  className?: string
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      className={className}
      style={{ color, opacity }}
      fill="currentColor"
      aria-hidden="true"
    >
      <circle cx="60" cy="60" r="13" />
      {Array.from({ length: 12 }).map((_, i) => (
        <ellipse
          key={i}
          cx="60"
          cy="18"
          rx="7"
          ry="18"
          transform={`rotate(${i * 30} 60 60)`}
        />
      ))}
    </svg>
  )
}

function DotGrid({
  cols = 6,
  rows = 5,
  gap = 14,
  dotSize = 2.5,
  color = 'white',
  opacity = 0.2,
  className = '',
}: {
  cols?: number
  rows?: number
  gap?: number
  dotSize?: number
  color?: string
  opacity?: number
  className?: string
}) {
  return (
    <svg
      width={cols * gap}
      height={rows * gap}
      className={className}
      style={{ opacity }}
      aria-hidden="true"
    >
      {Array.from({ length: rows }).flatMap((_, r) =>
        Array.from({ length: cols }).map((_, c) => (
          <circle
            key={`${r}-${c}`}
            cx={c * gap + gap / 2}
            cy={r * gap + gap / 2}
            r={dotSize}
            fill={color}
          />
        ))
      )}
    </svg>
  )
}

function WaveDivider({ flip = false }: { flip?: boolean }) {
  return (
    <div
      className="w-full leading-none pointer-events-none select-none"
      aria-hidden="true"
      style={{ transform: flip ? 'scaleY(-1)' : undefined }}
    >
      <svg viewBox="0 0 1440 56" preserveAspectRatio="none" className="w-full" style={{ height: 56, display: 'block' }}>
        <path
          d="M0,28 C240,0 480,56 720,28 C960,0 1200,56 1440,28 L1440,56 L0,56 Z"
          fill={CREAM}
        />
      </svg>
    </div>
  )
}

// ─── Partner column ─────────────────────────────────────────────────────────────
function PartnerColumn({
  partner,
  locale,
  bgColor,
  textColor,
  accentColor,
  dotsColor,
  sunflowerColor,
  emojiPlaceholder,
}: {
  partner: Partner
  locale: Locale
  bgColor: string
  textColor: string
  accentColor: string
  dotsColor: string
  sunflowerColor: string
  emojiPlaceholder: string
}) {
  const [imgError, setImgError] = useState(false)

  return (
    <div
      className="relative flex flex-col items-center justify-center gap-4 h-full overflow-hidden px-4 py-8"
      style={{ backgroundColor: bgColor }}
    >
      {/* Background sunflower */}
      <div className="absolute -bottom-6 -right-6 pointer-events-none">
        <SunflowerDecor size={170} color={sunflowerColor} opacity={0.12} />
      </div>
      {/* Dot grid corner */}
      <div className="absolute top-4 left-4 pointer-events-none">
        <DotGrid cols={4} rows={4} gap={13} dotSize={2} color={dotsColor} opacity={0.18} />
      </div>

      {/* Logo container */}
      <div
        className="relative z-10 w-[72px] h-[72px] md:w-[88px] md:h-[88px] rounded-2xl flex items-center justify-center overflow-hidden shadow-md"
        style={{ backgroundColor: accentColor }}
      >
        {imgError ? (
          <span className="text-3xl">{emojiPlaceholder}</span>
        ) : (
          <img
            src={partner.logo}
            alt={partner.name[locale]}
            className="w-full h-full object-contain p-3"
            onError={() => setImgError(true)}
          />
        )}
      </div>

      {/* Org name */}
      <p
        className="relative z-10 text-center text-xs md:text-sm font-semibold leading-snug max-w-[130px]"
        style={{ color: textColor }}
      >
        {partner.name[locale]}
      </p>
    </div>
  )
}

// ─── Main component ─────────────────────────────────────────────────────────────
export function LandingPage({
  hero,
  partners,
  content,
  locale: initialLocale = 'uk',
  onFamilyRegister,
  onDonorBrowse,
  onLocaleChange,
}: LandingPageProps) {
  const [locale, setLocale] = useState<Locale>(initialLocale)
  const [heroImgError, setHeroImgError] = useState(false)
  const t = content[locale]

  useEffect(() => {
    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href =
      'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,700;0,9..40,800;1,9..40,400&display=swap'
    document.head.appendChild(link)
    return () => { document.head.removeChild(link) }
  }, [])

  function toggleLocale() {
    const next: Locale = locale === 'uk' ? 'en' : 'uk'
    setLocale(next)
    onLocaleChange?.(next)
  }

  const [partner1, partner2] = partners

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ backgroundColor: CREAM, fontFamily: "'DM Sans', system-ui, sans-serif" }}
    >

      {/* ─── HEADER ──────────────────────────────────────────────────────────── */}
      <header
        className="sticky top-0 z-50 bg-white"
        style={{ borderBottom: `2.5px solid ${BLUE}` }}
      >
        <div className="max-w-7xl mx-auto px-5 sm:px-8 h-[62px] flex items-center justify-between">
          {/* Wordmark */}
          <div className="flex items-center gap-2.5">
            <div
              className="w-8 h-8 rounded-xl flex items-center justify-center shadow-sm flex-shrink-0"
              style={{ backgroundColor: BLUE }}
            >
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
                <path
                  d="M9 2C6 2 3.5 4.5 3.5 7.5C3.5 11 6.5 14 9 16C11.5 14 14.5 11 14.5 7.5C14.5 4.5 12 2 9 2Z"
                  fill="white"
                  opacity="0.85"
                />
                <path
                  d="M9 5.5C7.2 5.5 5.5 7 5.5 8.8C5.5 10.5 7.2 12 9 13C10.8 12 12.5 10.5 12.5 8.8C12.5 7 10.8 5.5 9 5.5Z"
                  fill="white"
                />
              </svg>
            </div>
            <span className="text-sm font-bold" style={{ color: NAVY }}>
              Family to Family
            </span>
          </div>

          {/* Language toggle */}
          <button
            onClick={toggleLocale}
            className="px-4 py-1.5 text-xs font-bold tracking-widest uppercase rounded-full border-2 transition-all duration-200"
            style={{ borderColor: BLUE, color: BLUE }}
            onMouseEnter={e => {
              e.currentTarget.style.backgroundColor = BLUE
              e.currentTarget.style.color = 'white'
            }}
            onMouseLeave={e => {
              e.currentTarget.style.backgroundColor = 'transparent'
              e.currentTarget.style.color = BLUE
            }}
          >
            {t.languageToggle}
          </button>
        </div>
      </header>

      {/* ─── HERO ROW ─────────────────────────────────────────────────────────── */}
      {/*   Desktop  : 3fr  1fr  1fr  (grid-cols-5: photo=col-span-3, each partner=col-span-1) */}
      {/*   Mobile   : photo full-width, partners side-by-side below                          */}
      <div className="flex-none">
        <div
          className="grid grid-cols-2 md:grid-cols-5"
          style={{ height: 'min(92vh, 700px)' }}
        >
          {/* ── Photo column ── */}
          <div className="col-span-2 md:col-span-3 relative overflow-hidden" style={{ backgroundColor: BLUE_DEEP }}>
            {heroImgError ? (
              /* Fallback: illustrated blue placeholder */
              <div
                className="w-full h-full flex flex-col items-center justify-center gap-4 relative"
                style={{ backgroundColor: BLUE_DEEP }}
              >
                <div className="absolute inset-0 pointer-events-none">
                  <DotGrid cols={14} rows={10} gap={28} dotSize={3} color="white" opacity={0.07} className="absolute inset-0 m-auto" />
                </div>
                <div className="w-28 h-28 md:w-40 md:h-40 rounded-full bg-white/15 flex items-center justify-center border-4 border-white/20">
                  <span
                    className="text-4xl md:text-6xl font-black text-white/60 select-none"
                  >
                    {hero.name[locale].split(' ').slice(0, 2).map(n => n[0]).join('')}
                  </span>
                </div>
                <p className="text-white/50 text-sm font-medium">{hero.name[locale]}</p>
              </div>
            ) : (
              <>
                <img
                  src={hero.photo}
                  alt={hero.name[locale]}
                  className="w-full h-full object-cover object-top"
                  onError={() => setHeroImgError(true)}
                />
              </>
            )}

            {/* Dot grid — top-right decorative */}
            <div className="absolute top-5 right-5 pointer-events-none">
              <DotGrid cols={8} rows={7} gap={15} dotSize={2.5} color="white" opacity={0.15} />
            </div>

            {/* Sunflower petal — top-left */}
            <div className="absolute -top-8 -left-8 pointer-events-none">
              <SunflowerDecor size={180} color={GOLD} opacity={0.14} />
            </div>

            {/* Gradient overlay — bottom half */}
            <div
              className="absolute inset-x-0 bottom-0 pointer-events-none"
              style={{
                height: '60%',
                background: `linear-gradient(to top, ${NAVY}dd 0%, ${NAVY}88 45%, transparent 100%)`,
              }}
            />

            {/* Name / title overlay */}
            <div className="absolute bottom-0 left-0 right-0 px-6 pb-7 pt-20 flex flex-col gap-1">
              {/* Gold accent pill */}
              <div
                className="mb-2 self-start px-3 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide"
                style={{ backgroundColor: GOLD, color: NAVY }}
              >
                {hero.title[locale]}
              </div>
              <h1
                className="text-white text-xl md:text-3xl font-black leading-tight"
              >
                {hero.name[locale]}
              </h1>
            </div>
          </div>

          {/* ── Partner 1 column — Ukrainian blue ── */}
          {partner1 && (
            <div className="col-span-1 h-full">
              <PartnerColumn
                partner={partner1}
                locale={locale}
                bgColor={BLUE}
                textColor="white"
                accentColor="rgba(255,255,255,0.15)"
                dotsColor="white"
                sunflowerColor="white"
                emojiPlaceholder="🕊️"
              />
            </div>
          )}

          {/* ── Partner 2 column — sunflower gold ── */}
          {partner2 && (
            <div className="col-span-1 h-full">
              <PartnerColumn
                partner={partner2}
                locale={locale}
                bgColor={GOLD}
                textColor={NAVY}
                accentColor="rgba(255,255,255,0.5)"
                dotsColor={NAVY}
                sunflowerColor={GOLD_DEEP}
                emojiPlaceholder="🛡️"
              />
            </div>
          )}
        </div>
      </div>

      {/* ─── WAVE TRANSITION ──────────────────────────────────────────────────── */}
      <div className="relative -mt-1" style={{ backgroundColor: BLUE_FAINT }}>
        <WaveDivider />
      </div>

      {/* ─── MISSION + CTAs ───────────────────────────────────────────────────── */}
      <section
        className="relative py-16 md:py-24 px-4 text-center overflow-hidden"
        style={{ backgroundColor: CREAM }}
      >
        {/* Decorative sunflowers — far sides */}
        <div className="absolute -left-10 top-1/2 -translate-y-1/2 pointer-events-none">
          <SunflowerDecor size={220} color={GOLD} opacity={0.09} />
        </div>
        <div className="absolute -right-10 top-1/2 -translate-y-1/2 pointer-events-none">
          <SunflowerDecor size={220} color={BLUE} opacity={0.07} />
        </div>
        {/* Small dot cluster — center-top */}
        <div className="absolute top-6 left-1/2 -translate-x-1/2 pointer-events-none">
          <DotGrid cols={9} rows={2} gap={16} dotSize={2} color={GOLD} opacity={0.3} />
        </div>

        {/* ── Emblem-style ornament ── */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="h-px flex-1 max-w-[80px] rounded-full" style={{ backgroundColor: GOLD }} />
          <SunflowerDecor size={28} color={GOLD} opacity={0.9} />
          <div className="h-px flex-1 max-w-[80px] rounded-full" style={{ backgroundColor: GOLD }} />
        </div>

        {/* Mission statement */}
        <div className="relative z-10 max-w-2xl mx-auto">
          <p
            className="text-lg md:text-xl font-medium leading-relaxed"
            style={{ color: NAVY }}
          >
            {t.missionLine1}
          </p>
          <p
            className="text-lg md:text-xl font-medium leading-relaxed mt-1.5"
            style={{ color: NAVY }}
          >
            {t.missionLine2}
          </p>
        </div>

        {/* ── CTA buttons ── */}
        <div className="relative z-10 mt-12 flex flex-col sm:flex-row gap-4 items-center justify-center">
          {/* "We Need Help" — Ukrainian blue */}
          <button
            onClick={onFamilyRegister}
            className="w-full sm:w-auto px-10 py-4 text-base font-black text-white rounded-full shadow-lg transition-all duration-200 hover:-translate-y-1 hover:shadow-2xl active:translate-y-0"
            style={{ backgroundColor: BLUE, minWidth: 220 }}
            onMouseEnter={e => { e.currentTarget.style.backgroundColor = BLUE_DEEP }}
            onMouseLeave={e => { e.currentTarget.style.backgroundColor = BLUE }}
          >
            {t.ctaFamily}
          </button>

          {/* "I Want to Help" — coral */}
          <button
            onClick={onDonorBrowse}
            className="w-full sm:w-auto px-10 py-4 text-base font-black text-white rounded-full shadow-lg transition-all duration-200 hover:-translate-y-1 hover:shadow-2xl active:translate-y-0"
            style={{ backgroundColor: CORAL, minWidth: 220 }}
            onMouseEnter={e => { e.currentTarget.style.backgroundColor = CORAL_DEEP }}
            onMouseLeave={e => { e.currentTarget.style.backgroundColor = CORAL }}
          >
            {t.ctaDonor}
          </button>
        </div>

        {/* Bottom ornament */}
        <div className="flex items-center justify-center gap-3 mt-10">
          <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: GOLD, opacity: 0.5 }} />
          <div className="h-px w-16 rounded-full" style={{ backgroundColor: GOLD, opacity: 0.3 }} />
          <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: GOLD, opacity: 0.5 }} />
        </div>
      </section>

    </div>
  )
}
